import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": "http://127.0.0.1:8017",
      "/ws": { target: "ws://127.0.0.1:8017", ws: true },
    },
  },
  test: {
    environment: "jsdom",
    pool: "threads",
    maxWorkers: 1,
  },
});
