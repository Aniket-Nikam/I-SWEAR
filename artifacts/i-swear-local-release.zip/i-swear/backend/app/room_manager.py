from __future__ import annotations

import asyncio
import math
import secrets
import time
import copy
import logging
from hashlib import sha256
from dataclasses import dataclass, field
from typing import Any

from fastapi import WebSocket, WebSocketDisconnect

from .models import RoomPhase
from .world import integrate, line_clear, blocked
from .maps import MAP_INFO, map_data, map_scenario
from .mystery import Memory, Scenario, assign_memories, contradictions
from .investigation import BINDINGS, CASE_BINDINGS, SECONDARY_RECORDS, recover_evidence, resolve_source, resolve_sources, timeline_public
from .casefile import assign_motive, case_public, private_motive, stage, timing
from .scoring import accurate, compute_results
from .demo import advance_demo
from .archivist import Archivist, FALLBACK_INTRO

MIN_PLAYERS = 4
MAX_PLAYERS = 8
INTERACTION_RADIUS = 96.0
# Compatibility exports for local tooling; gameplay always selects the room's map.
SPAWNS = map_data()["spawns"]
INTERACTABLES = map_data()["objects"]
WORLD_WIDTH, WORLD_HEIGHT = map_data()["width"], map_data()["height"]


@dataclass
class Player:
    id: str
    name: str
    token: str
    color_index: int
    x: float
    y: float
    ready: bool = False
    connected: bool = False
    last_seen: float = field(default_factory=time.monotonic)
    last_move: float = field(default_factory=time.monotonic)
    last_sequence: int = -1
    websocket: WebSocket | None = None
    dx: float = 0.0
    dy: float = 0.0
    vx: float = 0.0
    vy: float = 0.0
    last_input: float = field(default_factory=time.monotonic)
    afk: bool = False
    action_times: list[float] = field(default_factory=list)
    memories: tuple[Memory, ...] = ()
    last_chat: float = 0.0
    evidence_found: set[str] = field(default_factory=set)
    theory_edits: int = 0
    is_bot: bool = False
    token_hash: str = ""
    avatar_color: int | None = None
    hat: str = "none"
    account_id: str | None = None
    motive: dict | None = None
    motive_revealed: bool = False
    linked_records: int = 0
    post_theory_edits: int = 0
    motive_notice: tuple | None = None

    def public(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "color_index": self.color_index,
            "avatar_color": self.avatar_color if self.avatar_color is not None else self.color_index,
            "hat": self.hat,
            "x": round(self.x, 2),
            "y": round(self.y, 2),
            "ready": self.ready,
            "connected": self.connected,
            "afk": self.afk,
            "vx": round(self.vx, 2),
            "vy": round(self.vy, 2),
            "dx": self.dx,
            "dy": self.dy,
            "input_sequence": self.last_sequence,
            "is_bot": self.is_bot,
        }


@dataclass
class Room:
    code: str
    host_id: str
    phase: RoomPhase = RoomPhase.LOBBY
    players: dict[str, Player] = field(default_factory=dict)
    created_at: float = field(default_factory=time.monotonic)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    scenario: Scenario | None = None
    testimonies: dict[str, dict] = field(default_factory=dict)
    clashes: list[dict] = field(default_factory=list)
    chat: list[dict] = field(default_factory=list)
    evidence: dict[str, dict] = field(default_factory=dict)
    timeline: list[dict | None] = field(default_factory=lambda: [None] * 6)
    timeline_revision: int = 0
    lock_votes: set[str] = field(default_factory=set)
    theory_changes: int = 0
    round_number: int = 1
    result: dict | None = None
    reveal_started_at: float | None = None
    instability_used: bool = False
    solo: bool = False
    tutorial: bool = False
    demo_elapsed: float = 0.0
    demo_navigation: dict[str, int] = field(default_factory=dict)
    demo_steps: set[str] = field(default_factory=set)
    consensus_events: set[str] = field(default_factory=set)
    response_history: list[dict] = field(default_factory=list)
    ai_requests: int = 0
    ai_setup_done: bool = False
    ai_recap_done: bool = False
    intro: str = FALLBACK_INTRO
    is_public: bool = False
    max_players: int = MAX_PLAYERS
    map_id: str = "campus"
    rules_version: int = 1
    case_elapsed: float = 0.0
    case_second: int = -1
    first_theory: dict | None = None
    theory_votes: set[str] = field(default_factory=set)
    deadline_used: bool = False

    def snapshot(self) -> dict[str, Any]:
        return {
            "type": "snapshot",
            "room": {
                "code": self.code,
                "host_id": self.host_id,
                "phase": self.phase.value,
                "min_players": MIN_PLAYERS,
                "max_players": self.max_players,
                "solo": self.solo,
                "tutorial": self.tutorial,
                "is_public": self.is_public,
                "map_id": self.map_id,
                "map": MAP_INFO[self.map_id],
            },
            "players": [player.public() for player in self.players.values()],
            "interactables": [
                {**{key: value for key, value in item.items() if key != "detail"},
                 **({"clearance": list(CASE_BINDINGS).index(item["id"]) % 4, "backup": item["id"] in SECONDARY_RECORDS}
                    if self.rules_version >= 2 and item["id"] in CASE_BINDINGS else {})}
                for item in map_data(self.map_id)["objects"]
            ],
            "world": {key: map_data(self.map_id)[key] for key in ("width", "height", "rooms", "walls", "furniture", "obstacles", "doors", "layout_version")},
            "testimonies": list(self.testimonies.values()),
            "clashes": self.clashes,
            "chat": self.chat,
            "evidence": list(self.evidence.values()),
            "timeline": timeline_public(self),
            "result": self.result if self.phase in (RoomPhase.REVEAL, RoomPhase.RESULTS) else None,
            "reveal_started_at": self.reveal_started_at,
            "case": case_public(self),
        }


class RoomError(Exception):
    pass


class RoomManager:
    def __init__(self) -> None:
        self.rooms: dict[str, Room] = {}
        self.repository = None
        self.archivist = Archivist()
        self.presentation_tasks: set[asyncio.Task] = set()
        self.result_tasks: set[asyncio.Task] = set()
        self.pending_checkpoints: dict[str, Room] = {}
        self.checkpoint_task: asyncio.Task | None = None

    def request_checkpoint(self, room):
        if not self.repository or room.code not in self.rooms:
            return
        self.pending_checkpoints[room.code] = room
        if self.checkpoint_task is None or self.checkpoint_task.done():
            self.checkpoint_task = asyncio.create_task(self.flush_checkpoints())

    async def flush_checkpoints(self):
        # One writer, one pending room reference per code. Database latency never
        # prevents the same witness's socket from reading their next movement.
        while self.pending_checkpoints:
            rooms = [room for code, room in self.pending_checkpoints.items() if code in self.rooms]
            self.pending_checkpoints.clear()
            if not rooms:
                return
            try:
                await self.repository.apersist_rooms(rooms)
            except Exception as error:
                self.pending_checkpoints.update((room.code, room) for room in rooms if room.code in self.rooms)
                logging.getLogger("i-swear").warning("Room checkpoint unavailable (%s); periodic save will retry", type(error).__name__)
                return

    def present(self, coroutine):
        task = asyncio.create_task(coroutine)
        self.presentation_tasks.add(task)
        task.add_done_callback(self.presentation_tasks.discard)

    @staticmethod
    def _code() -> str:
        alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return "".join(secrets.choice(alphabet) for _ in range(5))

    @staticmethod
    def _player(name: str, index: int, map_id="campus") -> Player:
        x, y = map_data(map_id)["spawns"][index]
        player = Player(
            id=secrets.token_urlsafe(8),
            name=name,
            token=secrets.token_urlsafe(24),
            color_index=index,
            x=x,
            y=y,
        )
        player.token_hash = sha256(player.token.encode()).hexdigest()
        return player

    def create(self, name: str, map_id="campus") -> tuple[Room, Player]:
        if map_id not in MAP_INFO:
            raise RoomError("Unknown map")
        code = self._code()
        while code in self.rooms:
            code = self._code()
        player = self._player(name, 0, map_id)
        room = Room(code=code, host_id=player.id, players={player.id: player}, map_id=map_id, rules_version=2)
        self.rooms[code] = room
        return room, player

    def join(self, code: str, name: str) -> tuple[Room, Player]:
        room = self.rooms.get(code.upper())
        if not room:
            raise RoomError("Room not found")
        if room.solo:
            raise RoomError("This is a private solo rehearsal. Create a multiplayer room to invite friends.")
        if room.phase is not RoomPhase.LOBBY:
            raise RoomError("Investigation already in progress")
        if len(room.players) >= room.max_players:
            raise RoomError("Room is full")
        normalized = name.casefold()
        if any(player.name.casefold() == normalized for player in room.players.values()):
            raise RoomError("That witness name is already in use")
        occupied = {player.color_index for player in room.players.values()}
        player = self._player(name, next(index for index in range(MAX_PLAYERS) if index not in occupied), room.map_id)
        room.players[player.id] = player
        return room, player

    async def appearance(self, room, player, color, hat):
        if room.phase is not RoomPhase.LOBBY:
            raise RoomError("Change your outfit in the lobby.")
        player.avatar_color, player.hat = color, hat
        await self.broadcast(room, {"type": "presence", "player": player.public()})

    async def leave(self, room, player, websocket):
        await self.disconnect(room, player, websocket)
        if room.phase is not RoomPhase.LOBBY:
            return
        room.players.pop(player.id, None)
        if not any(not witness.is_bot for witness in room.players.values()):
            self.rooms.pop(room.code, None)
            self.pending_checkpoints.pop(room.code, None)
            if self.repository:
                await self.repository.adelete_room(room.code)
            return
        await self.broadcast(room, room.snapshot())

    def create_solo(self, name: str, map_id="campus", tutorial=False) -> tuple[Room, Player]:
        room, player = self.create(name, map_id)
        player.ready = True
        for index, bot_name in enumerate(("Riya", "Mina", "Omar"), start=1):
            bot = self._player(f"{bot_name} (scripted)", index, map_id)
            bot.is_bot = bot.connected = bot.ready = True
            room.players[bot.id] = bot
        room.solo = True
        room.tutorial = tutorial
        return room, player

    def authenticate(self, code: str, player_id: str, token: str) -> tuple[Room, Player]:
        room = self.rooms.get(code.upper())
        if not room or player_id not in room.players:
            raise RoomError("Session not found")
        player = room.players[player_id]
        if not secrets.compare_digest(player.token_hash, sha256(token.encode()).hexdigest()):
            raise RoomError("Invalid reconnect token")
        return room, player

    async def broadcast(self, room: Room, payload: dict[str, Any], exclude: str | None = None) -> None:
        stale: list[tuple[Player, WebSocket]] = []
        for player in list(room.players.values()):
            if player.id == exclude or not player.connected or not player.websocket:
                continue
            try:
                await player.websocket.send_json(payload)
            except (RuntimeError, WebSocketDisconnect, OSError):
                stale.append((player, player.websocket))
        for player, websocket in stale:
            await self.disconnect(room, player, websocket)

    async def connect(self, room: Room, player: Player, websocket: WebSocket) -> None:
        # Saved rooms can predate a physical-layout update. Restore a walkable spot
        # before publishing positions; the canonical incident is never changed.
        self.restore_walkable_positions(room)
        if player.websocket and player.websocket is not websocket:
            try:
                await player.websocket.close(code=4001, reason="Session opened elsewhere")
            except (RuntimeError, WebSocketDisconnect, OSError):
                pass
        player.websocket = websocket
        player.connected = True
        player.last_seen = time.monotonic()
        player.last_move = player.last_seen
        player.last_sequence = -1
        player.dx = player.dy = player.vx = player.vy = 0.0
        player.last_input = player.last_seen
        player.afk = False
        if not any(item.connected and item.id == room.host_id for item in room.players.values()):
            room.host_id = player.id
        await websocket.send_json(room.snapshot())
        if player.memories:
            await websocket.send_json({"type": "memories", "memories": [memory.private() for memory in player.memories]})
        await self.send_motive(room, player, force=True)
        await self.broadcast(room, {"type": "presence", "player": player.public()}, exclude=player.id)
        await self.broadcast(room, {"type": "timeline", "timeline": timeline_public(room)})
        if room.solo and room.phase is RoomPhase.LOBBY and player.ready:
            await self.start(room, player)

    def restore_walkable_positions(self, room):
        world = map_data(room.map_id)
        for witness in room.players.values():
            if not blocked(witness.x, witness.y, world["collision"]):
                continue
            origin = witness.x, witness.y
            found = False
            for radius in range(8, 257, 8):
                for dx, dy in ((0,-radius),(-radius,0),(radius,0),(0,radius),(-radius,-radius),(radius,-radius),(-radius,radius),(radius,radius)):
                    x, y = origin[0]+dx, origin[1]+dy
                    if 32 <= x <= world["width"]-32 and 32 <= y <= world["height"]-32 and not blocked(x,y,world["collision"]):
                        witness.x, witness.y = x, y
                        witness.dx = witness.dy = witness.vx = witness.vy = 0
                        found = True
                        break
                if found:
                    break

    async def disconnect(self, room: Room, player: Player, websocket: WebSocket) -> None:
        if player.websocket is not websocket:
            return
        player.connected = False
        player.dx = player.dy = player.vx = player.vy = 0.0
        player.websocket = None
        player.last_seen = time.monotonic()
        room.lock_votes.discard(player.id)
        room.theory_votes.discard(player.id)
        await self.broadcast(room, {"type": "presence", "player": player.public()})
        if player.id == room.host_id:
            candidates = [item for item in room.players.values() if item.connected and not item.is_bot]
            if candidates:
                room.host_id = candidates[0].id
                await self.broadcast(room, {"type": "host_changed", "host_id": room.host_id})
        await self.broadcast(room, {"type": "timeline", "timeline": timeline_public(room)})

    async def set_ready(self, room: Room, player: Player, ready: bool) -> None:
        if room.phase is not RoomPhase.LOBBY:
            return
        player.ready = ready
        await self.broadcast(room, {"type": "ready_changed", "player_id": player.id, "ready": ready})
        if room.solo and ready:
            await self.start(room, player)

    async def start(self, room: Room, player: Player) -> None:
        if player.id != room.host_id:
            raise RoomError("Only the host can begin")
        if room.phase is not RoomPhase.LOBBY:
            return
        if len(room.players) < MIN_PLAYERS:
            raise RoomError(f"At least {MIN_PLAYERS} witnesses are required")
        if not all(item.ready and item.connected for item in room.players.values()):
            raise RoomError("Every witness must be connected and ready")
        if room.solo and not room.tutorial and room.rules_version >= 2:
            from .navigation import demo_case_route
            await asyncio.to_thread(lambda: [demo_case_route(room.map_id, bot.color_index) for bot in room.players.values() if bot.is_bot])
        room.phase = RoomPhase.EXPLORING
        room.scenario = map_scenario(room.code, room.round_number, room.map_id)
        room.case_elapsed = 0.0
        rotation = secrets.randbelow(4)
        for index, witness in enumerate(room.players.values()):
            witness.memories = assign_memories(room.scenario, index, f"{room.code}-{room.round_number}",
                                               tuple(r["name"] for r in map_data(room.map_id)["rooms"][:3]) if room.map_id != "campus" else ())
            if witness.websocket:
                await witness.websocket.send_json({"type": "memories", "memories": [memory.private() for memory in witness.memories]})
            witness.motive = assign_motive(index + rotation) if room.rules_version >= 2 else None
            await self.send_motive(room, witness, force=True)
        if room.tutorial:
            # One concrete dispute; no timed testimony flood while learning.
            for bot in [p for p in room.players.values() if p.is_bot][::2]:
                memory = next(m for m in bot.memories if m.event_id == "arrival")
                await self.testify(room, bot, memory.id, 10)
        await self.broadcast(room, {"type": "phase_changed", "phase": room.phase.value})
        await self.refresh_case(room)
        self.present(self.archivist.setup(self, room))

    async def testify(self, room: Room, player: Player, memory_id: str, stake: int) -> None:
        if room.phase is not RoomPhase.EXPLORING:
            raise RoomError("The investigation has not begun")
        memory = next((item for item in player.memories if item.id == memory_id), None)
        if not memory:
            raise RoomError("That memory does not belong to you")
        existing = next((item for item in room.testimonies.values()
                         if item["player_id"] == player.id and item["memory"]["id"] == memory_id), None)
        if existing:
            existing.update(stake=stake, retracted=False)
            testimony = existing
        else:
            testimony = {"id": f"testimony_{len(room.testimonies) + 1}", "player_id": player.id,
                         "name": player.name, "memory": memory.private(), "stake": stake,
                         "responses": {}, "retracted": False}
            room.testimonies[testimony["id"]] = testimony
        player.last_seen = time.monotonic()
        await self.broadcast(room, {"type": "testimony", "testimony": testimony})
        for other in list(room.testimonies.values()):
            if other["player_id"] == player.id or other["retracted"]:
                continue
            fields = contradictions(testimony["memory"], other["memory"])
            pair = sorted((testimony["id"], other["id"]))
            if fields and not any(clash["testimony_ids"] == pair for clash in room.clashes):
                clash = {"id": f"clash_{len(room.clashes) + 1}", "testimony_ids": pair,
                         "fields": fields, "names": [testimony["name"], other["name"]]}
                room.clashes.append(clash)
                await self.broadcast(room, {"type": "clash", "clash": clash})

    async def respond(self, room: Room, player: Player, testimony_id: str, response: str, stake: int) -> None:
        if room.phase is not RoomPhase.EXPLORING:
            raise RoomError("The record is locked")
        testimony = room.testimonies.get(testimony_id)
        if not testimony or testimony["retracted"]:
            raise RoomError("Testimony is unavailable")
        if testimony["player_id"] == player.id:
            raise RoomError("Other witnesses respond to your testimony")
        testimony["responses"][player.id] = {"response": response, "stake": stake}
        previous = next((entry for entry in reversed(room.response_history)
                         if entry["player_id"] == player.id and entry["testimony_id"] == testimony_id), None)
        if previous and previous["response"] != response:
            room.theory_changes += 1
        room.response_history.append({"player_id": player.id, "testimony_id": testimony_id,
                                      "response": response, "stake": stake})
        player.last_seen = time.monotonic()
        await self.broadcast(room, {"type": "testimony", "testimony": testimony})
        if not accurate(room.scenario, testimony["memory"]):
            support = 1 + sum(item["response"] == "BELIEVE" for item in testimony["responses"].values())
            if support > len(room.players) // 2:
                room.consensus_events.add(testimony_id)
                if not room.instability_used:
                    room.instability_used = True
                    await self.broadcast(room, {"type": "archivist", "text": "MEMORY INSTABILITY DETECTED. At least one memory accepted by the majority is false."})

    async def retract(self, room: Room, player: Player, testimony_id: str) -> None:
        if room.phase is not RoomPhase.EXPLORING:
            raise RoomError("The record is locked")
        testimony = room.testimonies.get(testimony_id)
        if not testimony or testimony["player_id"] != player.id:
            raise RoomError("Only the witness can retract this testimony")
        testimony["retracted"] = True
        await self.broadcast(room, {"type": "testimony", "testimony": testimony})
        if room.rules_version >= 2 and any(entry and testimony_id in entry.get("source_ids", [entry["source_id"]]) for entry in room.timeline):
            room.lock_votes.clear()
            room.theory_votes.clear()
            room.timeline_revision += 1
            await self.broadcast(room, {"type": "timeline", "timeline": timeline_public(room)})

    async def chat_message(self, room: Room, player: Player, text: str) -> None:
        now = time.monotonic()
        if now - player.last_chat < 0.7:
            raise RoomError("Give the other witnesses a moment")
        clean = "".join(character for character in text.strip() if character.isprintable())[:280]
        if not clean:
            raise RoomError("Message is empty")
        player.last_chat = player.last_seen = now
        message = {"id": secrets.token_hex(6), "player_id": player.id, "name": player.name, "text": clean}
        room.chat.append(message)
        room.chat = room.chat[-60:]
        await self.broadcast(room, {"type": "chat", "message": message})

    async def move(self, room: Room, player: Player, dx: float, dy: float, sequence: int) -> None:
        if room.phase is not RoomPhase.EXPLORING or sequence <= player.last_sequence:
            return
        player.last_sequence = sequence
        player.dx, player.dy = dx, dy
        player.last_input = time.monotonic()
        if dx or dy:
            player.last_seen = player.last_input
            was_afk = player.afk
            player.afk = False
            if was_afk:
                await self.broadcast(room, {"type": "presence", "player": player.public()})

    async def tick(self, dt: float = 0.05) -> None:
        now = time.monotonic()
        for room in list(self.rooms.values()):
            if room.lock.locked():
                continue
            async with room.lock:
                await self.tick_room(room, dt, now)

    async def tick_room(self, room, dt, now):
        await self.advance_case(room, dt)
        if any(player.connected and not player.is_bot for player in room.players.values()):
            await advance_demo(self, room, max(0, dt))
        if room.phase is RoomPhase.REVEAL and room.reveal_started_at and time.time() - room.reveal_started_at >= 26:
            room.phase = RoomPhase.RESULTS
            await self.broadcast(room, {"type": "phase_changed", "phase": room.phase.value})
            self.request_checkpoint(room)
        changed = []
        for player in list(room.players.values()):
            if not player.connected:
                continue
            is_afk = now - player.last_seen > 90
            if player.afk != is_afk:
                player.afk = is_afk
                await self.broadcast(room, {"type": "presence", "player": player.public()})
            if room.phase is not RoomPhase.EXPLORING:
                continue
            if now - player.last_input > 0.3:
                player.dx = player.dy = 0.0
            previous = (player.x, player.y, player.vx, player.vy)
            # Keep real-time speed through ordinary scheduler jitter, without
            # allowing a long process stall to jump through walls.
            remaining = min(max(0, dt), 0.1)
            while remaining > 0:
                step = min(remaining, 0.025)
                player.x, player.y, player.vx, player.vy = integrate(
                    player.x, player.y, player.vx, player.vy, player.dx, player.dy, step, map_data(room.map_id))
                remaining = max(0, remaining - step)
            if previous != (player.x, player.y, player.vx, player.vy):
                changed.append(player.public())
        if changed:
            await self.broadcast(room, {"type": "positions", "players": changed, "at": time.monotonic()*1000})

    def check_rate(self, player: Player) -> bool:
        now = time.monotonic()
        player.action_times = [stamp for stamp in player.action_times if now - stamp < 1]
        if len(player.action_times) >= 60:
            return False
        player.action_times.append(now)
        return True

    async def interact(self, room: Room, player: Player, interactable_id: str) -> None:
        if room.phase is not RoomPhase.EXPLORING:
            raise RoomError("The investigation has not begun")
        player.last_seen = time.monotonic()
        item = next((value for value in map_data(room.map_id)["objects"] if value["id"] == interactable_id), None)
        if not item:
            raise RoomError("Unknown interactable")
        if math.hypot(player.x - item["x"], player.y - item["y"]) > INTERACTION_RADIUS:
            raise RoomError("Move closer to inspect that object")
        if not line_clear(player.x, player.y, item["x"], item["y"], map_data(room.map_id)["walls"]):
            raise RoomError("Move through the doorway to inspect this object.")
        if room.rules_version >= 2 and item["id"] in SECONDARY_RECORDS and room.case_elapsed < timing(room)[1]:
            if player.websocket:
                await player.websocket.send_json({"type": "inspection", "interactable": {**item, "detail": "Backup recovery is still running. This independent record will open with the new lead; compare your first theory meanwhile.", "evidence": None}})
            return
        evidence = recover_evidence(room.scenario, item["id"], partial=room.rules_version >= 2) if room.scenario else None
        if evidence and room.map_id != "campus":
            evidence["label"] = item["label"].upper() + " / LOCAL RECORD"
        access_note = None
        if evidence and evidence["id"] not in room.evidence:
            clearance = list(CASE_BINDINGS if room.rules_version >= 2 else BINDINGS).index(item["id"]) % 4
            if player.color_index % 4 != clearance:
                names = ", ".join(witness.name for witness in room.players.values() if witness.color_index % 4 == clearance)
                access_note = f"This recorder needs a different badge clearance. Ask {names} to inspect it."
                evidence = None
        if evidence:
            player.evidence_found.add(evidence["id"])
            if evidence["id"] not in room.evidence:
                room.evidence[evidence["id"]] = evidence
                await self.broadcast(room, {"type": "evidence", "evidence": evidence,
                                            "finder": player.name})
        detail = access_note or (evidence["text"] if evidence else item["detail"])
        if player.websocket:
            await player.websocket.send_json({"type": "inspection", "interactable": {**item, "detail": detail, "evidence": evidence}})
        await self.broadcast(
            room,
            {"type": "activity", "player_id": player.id, "verb": "inspected", "label": item["label"]},
            exclude=player.id,
        )

    async def edit_timeline(self, room: Room, player: Player, slot: int,
                            source_id: str | None, status: str, revision: int) -> None:
        if room.phase is not RoomPhase.EXPLORING:
            raise RoomError("The timeline is locked")
        if revision != room.timeline_revision:
            raise RoomError("Another witness updated the timeline. Review it and try again.")
        if not 0 <= slot < 6:
            raise RoomError("Unknown timeline slot")
        source = resolve_source(room, source_id) if source_id else None
        if source_id and not source:
            raise RoomError("Share the memory or recover the evidence before placing it")
        if source and room.rules_version >= 2:
            current = room.timeline[slot]
            ids = current.get("source_ids", [source_id]) if current and current["source_id"] == source_id else [source_id]
            try:
                source = resolve_sources(room, ids)
            except ValueError as error:
                raise RoomError(str(error)) from error
        if source:
            for index, entry in enumerate(room.timeline):
                if entry and entry["event_id"] == source["event_id"]:
                    room.timeline[index] = None
        room.timeline[slot] = {**source, "status": status} if source else None
        room.timeline_revision += 1
        room.theory_changes += 1
        player.theory_edits += 1
        if room.first_theory:
            player.post_theory_edits += 1
        room.lock_votes.clear()
        room.theory_votes.clear()
        player.last_seen = time.monotonic()
        await self.broadcast(room, {"type": "timeline", "timeline": timeline_public(room)})

    async def rematch(self, room: Room, player: Player) -> None:
        if player.id != room.host_id or room.phase is not RoomPhase.RESULTS:
            raise RoomError("The host can rematch after the reveal")
        room.phase = RoomPhase.LOBBY
        room.round_number += 1
        room.scenario = None
        room.result = None
        room.reveal_started_at = None
        room.testimonies.clear()
        room.clashes.clear()
        room.chat.clear()
        room.evidence.clear()
        room.timeline = [None] * 6
        room.timeline_revision = room.theory_changes = 0
        room.lock_votes.clear()
        room.instability_used = False
        room.demo_elapsed = 0.0
        room.demo_navigation.clear()
        room.demo_steps.clear()
        room.consensus_events.clear()
        room.response_history.clear()
        room.ai_requests = 0
        room.ai_setup_done = room.ai_recap_done = False
        room.intro = FALLBACK_INTRO
        room.rules_version = 2
        room.case_elapsed = 0.0
        room.case_second = -1
        room.first_theory = None
        room.theory_votes.clear()
        room.deadline_used = False
        for index, witness in enumerate(room.players.values()):
            witness.x, witness.y = map_data(room.map_id)["spawns"][index]
            witness.dx = witness.dy = witness.vx = witness.vy = 0.0
            witness.ready = witness.is_bot
            witness.memories = ()
            witness.evidence_found.clear()
            witness.theory_edits = 0
            witness.motive = None
            witness.motive_revealed = False
            witness.linked_records = witness.post_theory_edits = 0
            witness.motive_notice = None
        for witness in room.players.values():
            if witness.connected and witness.websocket:
                await witness.websocket.send_json(room.snapshot())
                await witness.websocket.send_json({"type": "memories", "memories": []})

    async def vote_lock(self, room: Room, player: Player, revision: int, vote: bool) -> None:
        if room.phase is not RoomPhase.EXPLORING or revision != room.timeline_revision:
            raise RoomError("The timeline changed. Review it before voting.")
        if room.rules_version >= 2 and room.case_elapsed < timing(room)[1]:
            raise RoomError("Compare your first theory. Final voting opens when the new lead arrives.")
        if not all(room.timeline):
            raise RoomError("Fill all six timeline positions before locking reality")
        if len(room.evidence) < 3:
            raise RoomError("Recover at least three physical records before locking reality")
        if any(any(not resolve_source(room, source_id) for source_id in entry.get("source_ids", [entry["source_id"]])) for entry in room.timeline):
            raise RoomError("A source was retracted. Replace it before voting.")
        if vote:
            room.lock_votes.add(player.id)
            if room.tutorial and not player.is_bot:
                room.lock_votes.update(item.id for item in room.players.values() if item.is_bot)
        else:
            room.lock_votes.discard(player.id)
        await self.broadcast(room, {"type": "timeline", "timeline": timeline_public(room)})
        required = timeline_public(room)["required_votes"]
        if room.phase is RoomPhase.EXPLORING and len(room.lock_votes) >= required:
            await self.finish_case(room)

    async def link_timeline(self, room, player, slot, source_id, revision, remove=False):
        if room.rules_version < 2 or room.phase is not RoomPhase.EXPLORING:
            raise RoomError("Deductions are not available in this case.")
        if revision != room.timeline_revision:
            raise RoomError("Another witness updated the timeline. Review it and try again.")
        if not 0 <= slot < 6:
            raise RoomError("Unknown timeline slot")
        entry = room.timeline[slot]
        if not entry:
            raise RoomError("Place a source before linking another one.")
        ids = list(entry.get("source_ids", [entry["source_id"]]))
        if remove:
            if source_id not in ids:
                raise RoomError("That source is not linked to this position.")
            ids = [value for value in ids if value != source_id and resolve_source(room, value)]
        elif source_id not in ids:
            ids.append(source_id)
        else:
            return
        try:
            linked = resolve_sources(room, ids) if ids else None
        except ValueError as error:
            raise RoomError(str(error)) from error
        room.timeline[slot] = {**linked, "status": entry["status"]} if linked else None
        room.timeline_revision += 1
        room.theory_changes += 1
        player.theory_edits += 1
        if room.first_theory:
            player.post_theory_edits += 1
        if not remove and linked and sum(source["kind"] == "evidence" for source in linked["sources"]) >= 2:
            player.linked_records += 1
        room.lock_votes.clear()
        room.theory_votes.clear()
        player.last_seen = time.monotonic()
        await self.broadcast(room, {"type": "timeline", "timeline": timeline_public(room)})

    def capture_theory(self, room, method):
        if room.first_theory is None:
            room.first_theory = {"slots": copy.deepcopy(room.timeline), "recorded_at": int(room.case_elapsed), "method": method}
        room.theory_votes.clear()

    async def vote_theory(self, room, player, revision, vote):
        discussion, lead, _, _ = timing(room)
        if room.rules_version < 2 or room.phase is not RoomPhase.EXPLORING or not discussion <= room.case_elapsed < lead:
            raise RoomError("The first-theory window is not open.")
        if room.first_theory or revision != room.timeline_revision:
            raise RoomError("The record changed. Review it before saving a theory.")
        if sum(bool(entry) for entry in room.timeline) < 3:
            raise RoomError("Propose at least three moments before recording a first theory.")
        if vote:
            room.theory_votes.add(player.id)
            if room.tutorial and not player.is_bot:
                room.theory_votes.update(item.id for item in room.players.values() if item.is_bot)
        else:
            room.theory_votes.discard(player.id)
        if len(room.theory_votes) >= timeline_public(room)["required_votes"]:
            self.capture_theory(room, "majority")

    async def reveal_motive(self, room, player):
        if room.phase is not RoomPhase.EXPLORING or not player.motive:
            raise RoomError("Your motive is unavailable.")
        player.motive_revealed = True

    async def send_motive(self, room, player, force=False):
        payload = private_motive(room, player)
        if payload and player.websocket:
            signature = (payload["revealed"], payload["progress"], payload["complete"])
            if force or signature != player.motive_notice:
                try:
                    await player.websocket.send_json({"type": "case_role", "role": payload})
                    player.motive_notice = signature
                except (RuntimeError, WebSocketDisconnect, OSError):
                    await self.disconnect(room, player, player.websocket)

    async def refresh_case(self, room):
        if room.rules_version >= 2:
            await self.broadcast(room, {"type": "case_state", "case": case_public(room)})
            for player in room.players.values():
                await self.send_motive(room, player)

    async def advance_case(self, room, dt):
        if room.rules_version < 2 or room.phase is not RoomPhase.EXPLORING:
            return
        if room.tutorial:
            return  # Lessons advance through learner actions, never a deadline.
        if not any(player.connected and not player.is_bot for player in room.players.values()):
            return
        previous = stage(room)[0]
        room.case_elapsed = min(timing(room)[3], room.case_elapsed + min(.1, max(0, dt)))
        if room.case_elapsed >= timing(room)[1] and room.first_theory is None:
            self.capture_theory(room, "checkpoint")
        if int(room.case_elapsed) != room.case_second:
            room.case_second = int(room.case_elapsed)
            await self.refresh_case(room)
        if previous != stage(room)[0]:
            await self.broadcast(room, {"type": "archivist", "text": {"first_theory": "Compare your first theory. You can record it by majority on the reconstruction board; three proposed moments are enough.", "new_lead": "The backup records are recovered. Revisit the marked sources and link them to your theory. The incident has not changed; your evidence has.", "final_call": "One minute remains. Revise your deductions and vote, or the clock will close the record as it stands."}[stage(room)[0]]})
        if room.case_elapsed >= timing(room)[3]:
            await self.finish_case(room, deadline=True)

    async def tutorial_action(self, room, player, action):
        if not room.tutorial or not room.solo or player.is_bot or room.phase is not RoomPhase.EXPLORING:
            raise RoomError("This action is only available in a guided tutorial.")
        if action == "lesson_lead":
            if not any(item["object_id"] == "atrium_badge" for item in room.evidence.values()):
                raise RoomError("Recover the badge scanner record first.")
            if not any(item["memory"]["event_id"] == "arrival" and player.id in item["responses"] for item in room.testimonies.values()):
                raise RoomError("Compare the arrival testimonies and respond to a witness first.")
            room.case_elapsed = timing(room)[1]
        elif action == "leads":
            if not room.first_theory:
                raise RoomError("Record your first theory on the board before opening the backup records.")
            room.case_elapsed = timing(room)[1]
        else:
            if not any(room.timeline):
                raise RoomError("Place one source on the board yourself before asking for a draft.")
            # Scripted witnesses offer their own memories. The helper has no
            # access to the canonical answers, and never replaces learner edits.
            for bot in room.players.values():
                if bot.is_bot:
                    for memory in bot.memories:
                        await self.testify(room, bot, memory.id, 10)
            sources = {item["event_id"]: item for item in room.evidence.values()}
            for item in room.testimonies.values():
                if not item["retracted"] and item["memory"]["event_id"] not in sources:
                    sources[item["memory"]["event_id"]] = {"id": item["id"], "claim": item["memory"]["claim"]}
            used = {entry["event_id"] for entry in room.timeline if entry}
            remaining = sorted((item for event, item in sources.items() if event not in used), key=lambda item: str(item["claim"].get("time", "")))
            for slot in range(6):
                if room.timeline[slot] is None and remaining:
                    source = remaining.pop(0)
                    await self.edit_timeline(room, player, slot, source["id"], "UNKNOWN", room.timeline_revision)
            if not room.first_theory:
                room.case_elapsed = timing(room)[0]
        await self.refresh_case(room)

    async def finish_case(self, room, deadline=False):
        if room.phase is not RoomPhase.EXPLORING:
            return
        room.deadline_used = deadline
        if room.rules_version >= 2:
            for index, entry in enumerate(room.timeline):
                if not entry:
                    continue
                ids = [source_id for source_id in entry.get("source_ids", [entry["source_id"]]) if resolve_source(room, source_id)]
                room.timeline[index] = {**resolve_sources(room, ids), "status": entry["status"]} if ids else None
        room.result = compute_results(room)
        room.phase = RoomPhase.REVEAL
        room.reveal_started_at = time.time()
        for witness in room.players.values():
            witness.dx = witness.dy = witness.vx = witness.vy = 0.0
        await self.broadcast(room, {"type": "reveal", "result": room.result, "started_at": room.reveal_started_at})
        await self.broadcast(room, {"type": "phase_changed", "phase": room.phase.value})
        self.request_checkpoint(room)
        if self.repository:
            task = asyncio.create_task(self.persist_result(room, copy.deepcopy(room.result)))
            self.result_tasks.add(task)
            task.add_done_callback(self.result_tasks.discard)
        self.present(self.archivist.recap(self, room))

    async def persist_result(self, room, result):
        try:
            saved = await self.repository.acomplete_match(result, [witness.name for witness in room.players.values()], [witness.account_id for witness in room.players.values() if witness.account_id])
            if room.result and room.result["replay_code"] == result["replay_code"]:
                room.result["best_score"] = saved["best_score"]
                self.request_checkpoint(room)
                await self.broadcast(room, {"type": "result_saved", "replay_code": result["replay_code"], "best_score": saved["best_score"]})
        except Exception as error:
            logging.getLogger("i-swear").warning("Result persistence unavailable (%s)", type(error).__name__)


manager = RoomManager()
